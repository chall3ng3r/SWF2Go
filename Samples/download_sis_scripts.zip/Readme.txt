Download SIS Script v1.0
===========================================
Author	: Faisal Iqbal (chall3ng3r)
Email	: ifaisal@orison.biz
Skype	: chall3ng3r
Blog	: www.orison.biz/blogs/chall3ng3r/
Website	: www.orison.biz
===========================================

Introduction:
=============
Download SIS Script allows to enable download of Symbian SIS files from webserver with correct MIME type required by S60 phones.

There are two scripts, one is for ASP.Net servers and other is for PHP servers. The script can be modified according to your needs. You can also redistribute script but please include the credit to original author of the script.

For security purposes, Download SIS Script will only allow download of SIS and SISX files. All other files will be ignored.

How to use:
===========
You have to upload the download_sis.php (if PHP server) script to same folder where SIS/SISX file(s) is located on your webserver.

You can initiate the download by making a requret like this:

for PHP: 
http://myserver.com/downloads/download_sis.php?file=my_swf2go_demo.sisx

for ASP.Net: 
http://myserver.com/downloads/download_sis.aspx?file=my_swf2go_demo.sisx

You can also make a HTML page, and make links (same like above examples) to download script. When the link is clicked, the download will begin with correct MIME type.
