<?php
$filename = $_GET['file'];

if(endsWith($filename, '.sisx'))
{
    header('Content-type: x-epoc/x-sisx-app');
	header('Content-Disposition: attachment; filename="'.$filename.'"');
	readfile($filename);
}
else if(endsWith($filename, '.sis'))
{
    header('Content-type: application/vnd.symbian.install');
	header('Content-Disposition: attachment; filename="'.$filename.'"');
	readfile($filename);
}
else
{
	print('Not file to download');
}

function endsWith( $str, $sub )
{
    return ( substr( $str, strlen( $str ) - strlen( $sub ) ) == $sub );
}
?>